:- use_module(library(lists)).
:- use_module(library(random)).
:- include('Utilities.pl').
:- include('Logic.pl').
:- include('Interface.pl').
:- include('Tiles.pl').

run:-
	menuStartingGame.